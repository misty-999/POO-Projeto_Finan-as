public class Utizador
{
    int id{ get; set; }
    String nome{ get; set; }
    String email{ get; set; }
    String senha { get; set; }
    String perfil{ get; set; }
}
