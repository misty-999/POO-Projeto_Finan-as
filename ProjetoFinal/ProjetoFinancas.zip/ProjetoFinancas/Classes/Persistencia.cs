public class Persistencia
{
    String caminhoArquivo { get; set; }
    
}   
