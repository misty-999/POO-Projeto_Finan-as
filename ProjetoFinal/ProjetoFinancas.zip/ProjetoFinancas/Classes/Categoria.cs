public class Categoria
{
    int id{ get; set; }
    String nome { get; set; }
    
}