public class Transacao
{
    public int Id { get; set; }
    public DateTime Data { get; set; }
    public float Valor { get; set; }
    public string Descricao { get; set; }
    public int Categoria { get; set; }
}   

